$my.query("drop table test")
