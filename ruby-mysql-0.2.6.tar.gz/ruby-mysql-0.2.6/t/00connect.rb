$my = Mysql.connect($host, $user, $passwd)
