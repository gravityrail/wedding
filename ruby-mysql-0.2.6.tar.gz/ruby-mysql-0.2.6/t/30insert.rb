$my.query("insert into test (id, str) values (1, 'foo')")
$my.query("insert into test (id, str) values (2, 'bar')")
