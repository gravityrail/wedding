$my.query("create table test (id int not null, str char(32) not null)")
