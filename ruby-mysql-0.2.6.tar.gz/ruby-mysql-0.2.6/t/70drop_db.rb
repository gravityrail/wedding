$my.query("drop database #{$db}")
$created = false
